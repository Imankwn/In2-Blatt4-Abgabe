package IN2.RataMe.controller;

import IN2.RataMe.model.Review;
import IN2.RataMe.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/reviews")
public class ReviewController {
    @Autowired
    private ReviewService service;

    @GetMapping("/mongo")
    public ResponseEntity<List<Review>> getAllMongoReviews() {
        return new ResponseEntity<>(service.findAllMongoReviews(), HttpStatus.OK);
    }

    @GetMapping("/sql")
    public ResponseEntity<List<Review>> getAllSqlReviews() {
        return new ResponseEntity<>(service.findAllH2Reviews(), HttpStatus.OK);
    }

    @PostMapping("/mongo/create")
    public ResponseEntity<Review> createMongoReview(@RequestBody Map<String, String> payload) {
        return new ResponseEntity<>(service.createMongoReview(payload.get("reviewBody"), payload.get("isbn")), HttpStatus.OK);
    }

    @PostMapping("/sql/create")
    public ResponseEntity<Review> createSqlReview(@RequestBody Map<String, String> payload) {
        return new ResponseEntity<>(service.createH2Review(payload.get("reviewBody"), payload.get("isbn")), HttpStatus.OK);
    }
}
