package IN2.RataMe.H2Repository;

import IN2.RataMe.model.Book;
import org.bson.types.ObjectId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface H2BookRepo extends JpaRepository<Movie, ObjectId> {
    Optional<Movie> findByImdbId(String imdbId);
}
