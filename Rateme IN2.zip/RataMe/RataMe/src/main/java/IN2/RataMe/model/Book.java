package IN2.RataMe.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Cascade;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;

import java.util.List;
@Document(collection = "book")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table (name="book")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String isbn;
    private String title;
    private String author;
    private String publicationDate;
    private String synopsis;
    private String coverImage;
    @Transient
    private List<String> chapterTitles;

    @Transient
    private List<String> genres;

    @DocumentReference
    @OneToMany
    @Cascade(org.hibernate.annotations.CascadeType.ALL)
    private List<Review> reviews;

    public Book(String isbn, String title, String author, String publicationDate, String synopsis, String coverImage, List<String> chapterTitles, List<String> genres) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publicationDate = publicationDate;
        this.synopsis = synopsis;
        this.coverImage = coverImage;
        this.chapterTitles = chapterTitles;
        this.genres = genres;
    }
}
