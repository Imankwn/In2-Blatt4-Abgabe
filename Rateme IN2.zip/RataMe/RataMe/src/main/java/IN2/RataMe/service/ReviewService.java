import IN2.RataMe.H2Repository.H2ReviewRepo;
import IN2.RataMe.service.BookService;
import IN2.RataMe.model.Book;
import IN2.RataMe.MongoRepository.MongoReviewRepo;
import IN2.RataMe.model.Review;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReviewService {
    @Autowired
    private MongoReviewRepo mongoRepository;

    @Autowired
    private H2ReviewRepo h2Repository;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private BookService bookService;

    public Review createMongoReview(String reviewBody, String isbn) {
        Review review = mongoRepository.insert(new Review(reviewBody, LocalDateTime.now(), LocalDateTime.now()));

        mongoTemplate.update(Book.class)
                .matching(Criteria.where("isbn").is(isbn))
                .apply(new Update().push("reviews").value(review))
                .first();

        return review;
    }

    public Review createH2Review(String reviewBody, String isbn) {
        List<Book> books = bookService.findAllH2Books();
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                Review review = new Review(reviewBody, LocalDateTime.now(), LocalDateTime.now());
                book.getReviews().add(review);
                bookService.createH2Book(book);
                return review;
            }
        }
        return null;
    }

    public List<Review> findAllMongoReviews() {
        return mongoRepository.findAll();
    }

    public List<Review> findAllH2Reviews() {
        return h2Repository.findAll();
    }
}
