package IN2.RataMe.controller;

import IN2.RataMe.model.Book;
import IN2.RataMe.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/books")
public class BookController {

    @Autowired
    private BookService service;

    @GetMapping("/mongo")
    public ResponseEntity<List<Book>> getMongoBooks() {
        return new ResponseEntity<>(service.findAllMongoBooks(), HttpStatus.OK);
    }

    @GetMapping("/mongo/{isbn}")
    public ResponseEntity<Optional<Book>> getMongoSingleBook(@PathVariable String isbn) {
        return new ResponseEntity<>(service.findMongoBookByIsbn(isbn), HttpStatus.OK);
    }

    @GetMapping("/sql")
    public ResponseEntity<List<Book>> getH2Books() {
        return new ResponseEntity<>(service.findAllH2Books(), HttpStatus.OK);
    }

    @GetMapping("/sql/{isbn}")
    public ResponseEntity<Optional<Book>> getH2SingleBook(@PathVariable String isbn) {
        return new ResponseEntity<>(service.findH2BookByIsbn(isbn), HttpStatus.OK);
    }

    @PostMapping("/sql/create")
    public ResponseEntity<Book> createSqlBook(@RequestBody Map<String, String> payload) {
        Book book = getBookRequest(payload);
        return new ResponseEntity<>(service.createH2Book(book), HttpStatus.OK);
    }

    @PostMapping("/mongo/create")
    public ResponseEntity<Book> createMongoBook(@RequestBody Map<String, String> payload) {
        Book book = getBookRequest(payload);
        return new ResponseEntity<>(service.createMongoBook(book), HttpStatus.OK);
    }

    private Book getBookRequest(Map<String, String> payload) {
        Book book = new Book();
        book.setIsbn(payload.get("isbn"));
        book.setTitle(payload.get("title"));
        book.setAuthor(payload.get("author"));
        book.setPublicationDate(payload.get("publicationDate"));
        book.setSynopsis(payload.get("synopsis"));
        book.setCoverImage(payload.get("coverImage"));
        book.setChapterTitles(new ArrayList<>());
        book.setGenres(new ArrayList<>());
        book.setReviews(new ArrayList<>());
        return book;
    }
}
}