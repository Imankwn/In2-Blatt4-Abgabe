package IN2.RataMe.H2Repository;

import IN2.RataMe.model.Review;
import org.bson.types.ObjectId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface H2ReviewRepo extends JpaRepository<Review, ObjectId> {
}