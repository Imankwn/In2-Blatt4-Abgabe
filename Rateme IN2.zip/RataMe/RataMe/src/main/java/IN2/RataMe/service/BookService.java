package IN2.RataMe.service;

import IN2.RataMe.H2Repository.H2BookRepo;
import IN2.RataMe.model.Book;
import IN2.RataMe.MongoRepository.MongoBookRepo;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private MongoBookRepo mongoRepository;

    @Autowired
    private H2BookRepo h2Repository;

    public List<Book> findAllMongoBooks() {
        List<Book> books = mongoRepository.findAll();
        for (Book book : books) {
            Hibernate.initialize(book.getReviews());
        }
        return books;
    }

    public Optional<Book> findMongoBookByIsbn(String isbn) {
        return mongoRepository.findBookByIsbn(isbn);
    }

    public List<Book> findAllH2Books() {
        List<Book> books = h2Repository.findAll();
        for (Book book : books) {
            Hibernate.initialize(book.getReviews());
        }
        return books;
    }

    public Optional<Book> findH2BookByIsbn(String isbn) {
        return h2Repository.findByIsbn(isbn);
    }

    public Book createH2Book(Book book) {
        h2Repository.save(book);
        return book;
    }

    public Book createMongoBook(Book book) {
        mongoRepository.save(book);
        return book;
    }
}
}