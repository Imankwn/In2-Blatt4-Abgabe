package IN2.RataMe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@ComponentScan(basePackages = {"IN2.RataMe.service", "IN2.RataMe.controller", "IN2.RataMe.model", "IN2.RataMe.configuration", "IN2.RataMe.MongoRepository", "IN2.RataMe.H2Repository"})
@EnableJpaRepositories(basePackages = "IN2.RataMe.H2Repository")
@EnableMongoRepositories(basePackages = "IN2.RataMe.MongoRepository")
@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}


}
