package IN2.RataMe.MongoRepository;

import IN2.RataMe.model.Review;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface MongoReviewRepo extends MongoRepository<Review, ObjectId> {
}
