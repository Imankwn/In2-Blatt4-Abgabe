package IN2.RataMe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RataMeApplicationTests {

	@Test
	private void contextLoads() {

	}

}
